import time

for i in range(10):
    print(i)


for i in range(0,21,2):
    print(i)
   
i = 0
while i <10:
    print(i)
    i += 1
